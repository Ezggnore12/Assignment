package Stockexample;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.text.DecimalFormat;
class Scratch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Movie> movies = new ArrayList<>();//make an array list in order to add and remove movies


        Movie m1 = new Movie("Avengers", "Blah blah blah", 150, 2000, 8.0);
        Movie m2 = new Movie("One upon a time in hollywood", "Yada yada", 240, 1958, 5.0);
        Movie m3 = new Movie("Train to busan", "Zombies in a train", 220, 2017, 9.6);
        Movie m4 = new Movie("Star wars:episode 2", "Pretty good light show", 240, 2004, 8.5);
        Movie m5 = new Movie("Warcraft", "FOR THE HORDE", 260, 2019, 7.5);//write dpwm the information on the first 5 movies
        movies.add(m1);//add movies into the array list
        movies.add(m2);
        movies.add(m3);
        movies.add(m4);
        movies.add(m5);
        Integer option = 0;
        while (option != 5) {// makes sure that the options repeats if the sentinel(5) is not inserted
            System.out.println("-------------------------");
            System.out.println("Movie repository");
            System.out.println("----------------------");
            System.out.println("1.View Movies");
            System.out.println("2.Add movies");
            System.out.println("3.Edit Movie");
            System.out.println("4.Delete Movie");
            System.out.println("5.EXIT");//provides options for the user to choose
            System.out.print("Choose option 1-5>> ");//enter options
            Scanner input = new Scanner(System.in);
            option = scanner.nextInt();//choose which options


            Integer query;

            if (option == 1) {
                System.out.print("Select movie from query:1,2,3,4,5: ");

                query = scanner.nextInt();
                if (query == 1) {
                    movies.get(query - 1).printmovie();
                } else if (query == 2) {
                    movies.get(query - 1).printmovie();
                } else if (query == 3) {
                    movies.get(query - 1).printmovie();
                    ;
                } else if (query == 4) {
                    movies.get(query - 1).printmovie();
                } else if (query == 5) {
                    movies.get(query - 1).printmovie();
                    //print out the description of the movie based on the query
                }


            } else if (option == 2) {
                System.out.println("Enter new movie title:");
                String newtitle = input.next();
                System.out.println("Enter sypnosis:");
                input.nextLine();
                String newsypnosis = input.nextLine();
                System.out.println("Enter movie length:");
                Integer newlength = input.nextInt();
                if (newlength < 0) {
                    System.out.println("ERROR!!CANNOT BE NEGATIVE");
                    continue;//if the length is less than 0 return to options
                }
                System.out.println("Enter release year:");
                Integer newrelease = input.nextInt();
                if (newrelease < 0) {
                    System.out.println("ERROR!!CANNOT BE NEGATIVE");
                    continue;//if the release date is less than 0 return back to options
                }
                System.out.println("Enter rating:");
                double newrating = input.nextDouble();
                if (newrating < 0 || newrating > 10) {
                    System.out.println("ERROR!!CANNOT BE NEGATIVE");
                    continue;
                }
                movies.add(new Movie(newtitle,newsypnosis,newlength,newrelease,newrating));
            } else if (option == 3) {
                System.out.println("Choose movie to edit from query:");
                query = input.nextInt();//edit whichever movie that is chosen in query
                if (query == 1) {
                    System.out.println("Editing Movie:\n");
                    movies.get(query - 1).printmovie();//(querry-1) because arrays starts from 0
                }
                if (query == 2) {
                    System.out.println("Editing Movie:\n");
                    movies.get(query - 1).printmovie();
                }
                if (query == 3) {
                    System.out.println("Editing Movie:\n");
                    movies.get(query - 1).printmovie();
                }
                if (query == 4) {
                    System.out.println("Editing movie:\n");
                    movies.get(query - 1).printmovie();
                }
                if (query == 5) {
                    System.out.println("Editing movie:\n");
                    movies.get(query - 1).printmovie();
                }

            } else if (option == 4) {
                System.out.println("Choose movie to delete from query:");
                query = input.nextInt();//deletes whichever movie that is chosen in query
                if (query == 1) {
                    System.out.println("Deleting Movie:\n");
                    movies.remove(query - 1).printmovie();//(querry-1) because arrays starts from 0
                }
                if (query == 2) {
                    System.out.println("Deleting Movie:\n");
                    movies.remove(query - 1).printmovie();
                }
                if (query == 3) {
                    System.out.println("Deleting Movie:\n");
                    movies.remove(query - 1).printmovie();
                }
                if (query == 4) {
                    System.out.println("Deleting movie:\n");
                    movies.remove(query - 1).printmovie();
                }
                if (query == 5) {
                    System.out.println("Deleting movie:\n");
                    movies.remove(query - 1).printmovie();
                }

            } else if (option == 5) {
                System.out.println("Thank you for using this program!!");//provide this message
                break;// completely end the program here when reach this sentinel value
            }
        }

    }
}







//





