package Stockexample;

import java.util.ArrayList;

public class Movie {
    String title;
    int length;
    String synopsis;
    int releaseyear;
    double rating;
    Movie(){
        //constructor
    }

    Movie(String newtitle,String newsynopsis, int newlength, int newreleaseyear, double newrating){
        title=newtitle;
        length=newlength;
        synopsis=newsynopsis;
        releaseyear=newreleaseyear;
        rating=newrating;
        //overloaded constructor in order to add new strings integers and double written by the user
    }
    public void printmovie(){
        System.out.println("Movie title: "+title);
        System.out.println("Movie length: "+length);
        System.out.println("Movie Synopsis: "+synopsis);
        System.out.println("Release year: "+releaseyear);
        System.out.println("Ratings: "+ rating);
        //print out these information when the
    }
}
